package com.example.vunit3213app.Models

data class DashboardResponse(
    val entities: List<Entity>,
    val entityTotal: Int
)
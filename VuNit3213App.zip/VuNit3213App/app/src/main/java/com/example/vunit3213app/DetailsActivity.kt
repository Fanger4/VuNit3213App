package com.example.vunit3213app

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.vunit3213app.Models.Entity

class DetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)


        val entity = intent.getSerializableExtra("entity") as? Entity
        findViewById<TextView>(R.id.property1).text = entity!!.property1
        findViewById<TextView>(R.id.property2).text = entity.property2
        findViewById<TextView>(R.id.description).text = entity.description
    }
}

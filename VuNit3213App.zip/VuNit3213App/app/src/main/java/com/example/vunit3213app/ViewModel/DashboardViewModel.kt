package com.example.vunit3213app.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.vunit3213app.Models.DashboardResponse
import com.example.vunit3213app.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class DashboardViewModel @Inject constructor(private val repository: Repository) : ViewModel() {

    val dashboardState = MutableLiveData<Result<DashboardResponse>>()

    fun loadDashboard(keypass: String) {
        viewModelScope.launch {
            dashboardState.value = repository.getDashboard(keypass)
        }
    }
}

package com.example.vunit3213app.ViewModel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.vunit3213app.Models.LoginResponse
import com.example.vunit3213app.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import jakarta.inject.Inject
import kotlinx.coroutines.launch

@HiltViewModel
class LoginViewModel @Inject constructor(private val repository: Repository) : ViewModel() {

    val loginState = MutableLiveData<Result<LoginResponse>>()

    fun login(username: String, password: String) {
        viewModelScope.launch {
            loginState.value = repository.login(username, password)
        }
    }
}

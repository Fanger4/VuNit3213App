package com.example.vunit3213app.Models

data class LoginResponse(val keypass: String)
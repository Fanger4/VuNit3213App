package com.example.vunit3213app

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.vunit3213app.Adapter.EntityAdapter

import com.example.vunit3213app.ViewModel.DashboardViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class DashboardActivity : AppCompatActivity() {

    private lateinit var viewModel: DashboardViewModel
    private lateinit var recyclerView: RecyclerView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        viewModel = ViewModelProvider(this).get(DashboardViewModel::class.java)

        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val keypass = intent.getStringExtra("keypass") ?: ""
        viewModel.loadDashboard(keypass)

        viewModel.dashboardState.observe(this) { result ->
            if (result.isSuccess) {
                val dashboard = result.getOrNull()
                recyclerView.adapter = EntityAdapter(dashboard?.entities ?: emptyList()) { entity ->
                    val intent = Intent(this, DetailsActivity::class.java)
                    intent.putExtra("entity",entity)
                    startActivity(intent)
                }
            } else {
                Toast.makeText(this, "Failed to load dashboard", Toast.LENGTH_SHORT).show()
            }
        }
    }
}



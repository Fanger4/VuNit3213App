package com.example.vunit3213app

import com.example.vunit3213app.Models.DashboardResponse
import com.example.vunit3213app.Models.LoginRequest
import com.example.vunit3213app.Models.LoginResponse
import jakarta.inject.Inject
import jakarta.inject.Singleton

@Singleton
class Repository @Inject constructor(private val apiService: ApiService) {

    suspend fun login(username: String, password: String): Result<LoginResponse> {
        return try {
            val response = apiService.login(LoginRequest(username, password))
            if (response.isSuccessful) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Login failed"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getDashboard(keypass: String): Result<DashboardResponse> {
        return try {
            val response = apiService.getDashboard(keypass)
            if (response.isSuccessful) {
                Result.success(response.body()!!)
            } else {
                Result.failure(Exception("Failed to fetch dashboard"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

package com.example.vunit3213app.Models

data class LoginRequest(val username: String, val password: String)
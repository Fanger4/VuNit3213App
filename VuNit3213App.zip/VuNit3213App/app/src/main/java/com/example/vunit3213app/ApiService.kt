package com.example.vunit3213app

import com.example.vunit3213app.Models.DashboardResponse
import com.example.vunit3213app.Models.LoginRequest
import com.example.vunit3213app.Models.LoginResponse
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {

    // Login request with Retrofit Response wrapper
    @POST("/footscray/auth")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    // Get dashboard data with Retrofit Response wrapper
    @GET("/dashboard/{keypass}")
    suspend fun getDashboard(@Path("keypass") keypass: String): Response<DashboardResponse>
}